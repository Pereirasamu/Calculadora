﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Bot7 = New System.Windows.Forms.Button()
        Me.Bot8 = New System.Windows.Forms.Button()
        Me.Bot9 = New System.Windows.Forms.Button()
        Me.Bot4 = New System.Windows.Forms.Button()
        Me.Bot5 = New System.Windows.Forms.Button()
        Me.Bot6 = New System.Windows.Forms.Button()
        Me.Bot1 = New System.Windows.Forms.Button()
        Me.Bot2 = New System.Windows.Forms.Button()
        Me.Bot3 = New System.Windows.Forms.Button()
        Me.Bot0 = New System.Windows.Forms.Button()
        Me.Botdividir = New System.Windows.Forms.Button()
        Me.BotMultiplicar = New System.Windows.Forms.Button()
        Me.Botsubtrair = New System.Windows.Forms.Button()
        Me.Botsomar = New System.Windows.Forms.Button()
        Me.BotCalcular = New System.Windows.Forms.Button()
        Me.Resultado = New System.Windows.Forms.TextBox()
        Me.BotBackspace = New System.Windows.Forms.Button()
        Me.TxtNum1 = New System.Windows.Forms.TextBox()
        Me.TxtOp = New System.Windows.Forms.TextBox()
        Me.botPonto = New System.Windows.Forms.Button()
        Me.botClean = New System.Windows.Forms.Button()
        Me.botInverter = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Bot7
        '
        Me.Bot7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bot7.Location = New System.Drawing.Point(17, 252)
        Me.Bot7.Margin = New System.Windows.Forms.Padding(4)
        Me.Bot7.Name = "Bot7"
        Me.Bot7.Size = New System.Drawing.Size(100, 49)
        Me.Bot7.TabIndex = 1
        Me.Bot7.Text = "7"
        Me.Bot7.UseVisualStyleBackColor = True
        '
        'Bot8
        '
        Me.Bot8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bot8.Location = New System.Drawing.Point(125, 252)
        Me.Bot8.Margin = New System.Windows.Forms.Padding(4)
        Me.Bot8.Name = "Bot8"
        Me.Bot8.Size = New System.Drawing.Size(100, 49)
        Me.Bot8.TabIndex = 2
        Me.Bot8.Text = "8"
        Me.Bot8.UseVisualStyleBackColor = True
        '
        'Bot9
        '
        Me.Bot9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bot9.Location = New System.Drawing.Point(231, 252)
        Me.Bot9.Margin = New System.Windows.Forms.Padding(4)
        Me.Bot9.Name = "Bot9"
        Me.Bot9.Size = New System.Drawing.Size(100, 49)
        Me.Bot9.TabIndex = 3
        Me.Bot9.Text = "9"
        Me.Bot9.UseVisualStyleBackColor = True
        '
        'Bot4
        '
        Me.Bot4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bot4.Location = New System.Drawing.Point(17, 309)
        Me.Bot4.Margin = New System.Windows.Forms.Padding(4)
        Me.Bot4.Name = "Bot4"
        Me.Bot4.Size = New System.Drawing.Size(100, 49)
        Me.Bot4.TabIndex = 4
        Me.Bot4.Text = "4"
        Me.Bot4.UseVisualStyleBackColor = True
        '
        'Bot5
        '
        Me.Bot5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bot5.Location = New System.Drawing.Point(125, 309)
        Me.Bot5.Margin = New System.Windows.Forms.Padding(4)
        Me.Bot5.Name = "Bot5"
        Me.Bot5.Size = New System.Drawing.Size(100, 49)
        Me.Bot5.TabIndex = 5
        Me.Bot5.Text = "5"
        Me.Bot5.UseVisualStyleBackColor = True
        '
        'Bot6
        '
        Me.Bot6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bot6.Location = New System.Drawing.Point(233, 309)
        Me.Bot6.Margin = New System.Windows.Forms.Padding(4)
        Me.Bot6.Name = "Bot6"
        Me.Bot6.Size = New System.Drawing.Size(100, 49)
        Me.Bot6.TabIndex = 6
        Me.Bot6.Text = "6"
        Me.Bot6.UseVisualStyleBackColor = True
        '
        'Bot1
        '
        Me.Bot1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bot1.Location = New System.Drawing.Point(17, 366)
        Me.Bot1.Margin = New System.Windows.Forms.Padding(4)
        Me.Bot1.Name = "Bot1"
        Me.Bot1.Size = New System.Drawing.Size(100, 49)
        Me.Bot1.TabIndex = 7
        Me.Bot1.Text = "1"
        Me.Bot1.UseVisualStyleBackColor = True
        '
        'Bot2
        '
        Me.Bot2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bot2.Location = New System.Drawing.Point(125, 366)
        Me.Bot2.Margin = New System.Windows.Forms.Padding(4)
        Me.Bot2.Name = "Bot2"
        Me.Bot2.Size = New System.Drawing.Size(100, 49)
        Me.Bot2.TabIndex = 8
        Me.Bot2.Text = "2"
        Me.Bot2.UseVisualStyleBackColor = True
        '
        'Bot3
        '
        Me.Bot3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bot3.Location = New System.Drawing.Point(233, 366)
        Me.Bot3.Margin = New System.Windows.Forms.Padding(4)
        Me.Bot3.Name = "Bot3"
        Me.Bot3.Size = New System.Drawing.Size(100, 49)
        Me.Bot3.TabIndex = 9
        Me.Bot3.Text = "3"
        Me.Bot3.UseVisualStyleBackColor = True
        '
        'Bot0
        '
        Me.Bot0.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bot0.Location = New System.Drawing.Point(125, 423)
        Me.Bot0.Margin = New System.Windows.Forms.Padding(4)
        Me.Bot0.Name = "Bot0"
        Me.Bot0.Size = New System.Drawing.Size(100, 49)
        Me.Bot0.TabIndex = 10
        Me.Bot0.Text = "0"
        Me.Bot0.UseVisualStyleBackColor = True
        '
        'Botdividir
        '
        Me.Botdividir.BackColor = System.Drawing.Color.Orange
        Me.Botdividir.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Botdividir.Location = New System.Drawing.Point(339, 165)
        Me.Botdividir.Margin = New System.Windows.Forms.Padding(4)
        Me.Botdividir.Name = "Botdividir"
        Me.Botdividir.Size = New System.Drawing.Size(100, 49)
        Me.Botdividir.TabIndex = 16
        Me.Botdividir.Text = "/"
        Me.Botdividir.UseVisualStyleBackColor = False
        '
        'BotMultiplicar
        '
        Me.BotMultiplicar.BackColor = System.Drawing.Color.Yellow
        Me.BotMultiplicar.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotMultiplicar.Location = New System.Drawing.Point(339, 222)
        Me.BotMultiplicar.Margin = New System.Windows.Forms.Padding(4)
        Me.BotMultiplicar.Name = "BotMultiplicar"
        Me.BotMultiplicar.Size = New System.Drawing.Size(100, 49)
        Me.BotMultiplicar.TabIndex = 16
        Me.BotMultiplicar.Text = "x"
        Me.BotMultiplicar.UseVisualStyleBackColor = False
        '
        'Botsubtrair
        '
        Me.Botsubtrair.BackColor = System.Drawing.Color.Crimson
        Me.Botsubtrair.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Botsubtrair.Location = New System.Drawing.Point(341, 279)
        Me.Botsubtrair.Margin = New System.Windows.Forms.Padding(4)
        Me.Botsubtrair.Name = "Botsubtrair"
        Me.Botsubtrair.Size = New System.Drawing.Size(100, 49)
        Me.Botsubtrair.TabIndex = 16
        Me.Botsubtrair.Text = "-"
        Me.Botsubtrair.UseVisualStyleBackColor = False
        '
        'Botsomar
        '
        Me.Botsomar.BackColor = System.Drawing.Color.LawnGreen
        Me.Botsomar.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Botsomar.Location = New System.Drawing.Point(340, 336)
        Me.Botsomar.Margin = New System.Windows.Forms.Padding(4)
        Me.Botsomar.Name = "Botsomar"
        Me.Botsomar.Size = New System.Drawing.Size(100, 49)
        Me.Botsomar.TabIndex = 15
        Me.Botsomar.Text = "+"
        Me.Botsomar.UseVisualStyleBackColor = False
        '
        'BotCalcular
        '
        Me.BotCalcular.BackColor = System.Drawing.SystemColors.HotTrack
        Me.BotCalcular.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotCalcular.Location = New System.Drawing.Point(340, 393)
        Me.BotCalcular.Margin = New System.Windows.Forms.Padding(4)
        Me.BotCalcular.Name = "BotCalcular"
        Me.BotCalcular.Size = New System.Drawing.Size(100, 79)
        Me.BotCalcular.TabIndex = 15
        Me.BotCalcular.Text = "="
        Me.BotCalcular.UseVisualStyleBackColor = False
        '
        'Resultado
        '
        Me.Resultado.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Resultado.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Resultado.Location = New System.Drawing.Point(19, 141)
        Me.Resultado.Margin = New System.Windows.Forms.Padding(4)
        Me.Resultado.Name = "Resultado"
        Me.Resultado.ReadOnly = True
        Me.Resultado.Size = New System.Drawing.Size(314, 34)
        Me.Resultado.TabIndex = 17
        Me.Resultado.Text = "0"
        Me.Resultado.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'BotBackspace
        '
        Me.BotBackspace.BackColor = System.Drawing.SystemColors.Control
        Me.BotBackspace.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotBackspace.Location = New System.Drawing.Point(17, 423)
        Me.BotBackspace.Margin = New System.Windows.Forms.Padding(4)
        Me.BotBackspace.Name = "BotBackspace"
        Me.BotBackspace.Size = New System.Drawing.Size(100, 49)
        Me.BotBackspace.TabIndex = 18
        Me.BotBackspace.Text = "<-"
        Me.BotBackspace.UseVisualStyleBackColor = False
        '
        'TxtNum1
        '
        Me.TxtNum1.BackColor = System.Drawing.SystemColors.Menu
        Me.TxtNum1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtNum1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtNum1.Location = New System.Drawing.Point(19, 85)
        Me.TxtNum1.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtNum1.Name = "TxtNum1"
        Me.TxtNum1.ReadOnly = True
        Me.TxtNum1.Size = New System.Drawing.Size(314, 34)
        Me.TxtNum1.TabIndex = 19
        Me.TxtNum1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TxtOp
        '
        Me.TxtOp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtOp.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtOp.Location = New System.Drawing.Point(339, 85)
        Me.TxtOp.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtOp.Name = "TxtOp"
        Me.TxtOp.ReadOnly = True
        Me.TxtOp.Size = New System.Drawing.Size(26, 34)
        Me.TxtOp.TabIndex = 20
        Me.TxtOp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'botPonto
        '
        Me.botPonto.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.botPonto.Location = New System.Drawing.Point(233, 423)
        Me.botPonto.Margin = New System.Windows.Forms.Padding(4)
        Me.botPonto.Name = "botPonto"
        Me.botPonto.Size = New System.Drawing.Size(100, 49)
        Me.botPonto.TabIndex = 21
        Me.botPonto.Text = "."
        Me.botPonto.UseVisualStyleBackColor = True
        '
        'botClean
        '
        Me.botClean.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.botClean.Location = New System.Drawing.Point(233, 195)
        Me.botClean.Margin = New System.Windows.Forms.Padding(4)
        Me.botClean.Name = "botClean"
        Me.botClean.Size = New System.Drawing.Size(100, 49)
        Me.botClean.TabIndex = 22
        Me.botClean.Text = "C"
        Me.botClean.UseVisualStyleBackColor = True
        '
        'botInverter
        '
        Me.botInverter.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.botInverter.Location = New System.Drawing.Point(125, 195)
        Me.botInverter.Margin = New System.Windows.Forms.Padding(4)
        Me.botInverter.Name = "botInverter"
        Me.botInverter.Size = New System.Drawing.Size(100, 49)
        Me.botInverter.TabIndex = 23
        Me.botInverter.Text = "+/-"
        Me.botInverter.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(479, 485)
        Me.Controls.Add(Me.botInverter)
        Me.Controls.Add(Me.botClean)
        Me.Controls.Add(Me.botPonto)
        Me.Controls.Add(Me.TxtOp)
        Me.Controls.Add(Me.TxtNum1)
        Me.Controls.Add(Me.BotBackspace)
        Me.Controls.Add(Me.Resultado)
        Me.Controls.Add(Me.BotCalcular)
        Me.Controls.Add(Me.Botsomar)
        Me.Controls.Add(Me.Botsubtrair)
        Me.Controls.Add(Me.BotMultiplicar)
        Me.Controls.Add(Me.Botdividir)
        Me.Controls.Add(Me.Bot0)
        Me.Controls.Add(Me.Bot3)
        Me.Controls.Add(Me.Bot2)
        Me.Controls.Add(Me.Bot1)
        Me.Controls.Add(Me.Bot6)
        Me.Controls.Add(Me.Bot5)
        Me.Controls.Add(Me.Bot4)
        Me.Controls.Add(Me.Bot9)
        Me.Controls.Add(Me.Bot8)
        Me.Controls.Add(Me.Bot7)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Bot7 As Button
    Friend WithEvents Bot8 As Button
    Friend WithEvents Bot9 As Button
    Friend WithEvents Bot4 As Button
    Friend WithEvents Bot5 As Button
    Friend WithEvents Bot6 As Button
    Friend WithEvents Bot1 As Button
    Friend WithEvents Bot2 As Button
    Friend WithEvents Bot3 As Button
    Friend WithEvents Bot0 As Button
    Friend WithEvents Botdividir As Button
    Friend WithEvents BotMultiplicar As Button
    Friend WithEvents Botsubtrair As Button
    Friend WithEvents Botsomar As Button
    Friend WithEvents BotCalcular As Button
    Friend WithEvents Resultado As TextBox
    Friend WithEvents BotBackspace As Button
    Friend WithEvents TxtNum1 As TextBox
    Friend WithEvents TxtOp As TextBox
    Friend WithEvents botPonto As Button
    Friend WithEvents botClean As Button
    Friend WithEvents botInverter As Button
End Class
